# Python Script
# https://www.electronicshub.org/raspberry-pi-l298n-interface-tutorial-control-dc-motor-l298n-raspberry-pi/

import RPi.GPIO as GPIO          
from time import sleep

inl1 = 24
inl2 = 23
enl = 25
inr1 = 27
inr2 = 17 
enr= 22
temp1=1

GPIO.setmode(GPIO.BCM)
GPIO.setup(inl1,GPIO.OUT)
GPIO.setup(inl2,GPIO.OUT)
GPIO.setup(enl,GPIO.OUT)
GPIO.output(inl1,GPIO.LOW)
GPIO.output(inl2,GPIO.LOW)
pl=GPIO.PWM(enl,1000)

GPIO.setmode(GPIO.BCM)
GPIO.setup(inr1,GPIO.OUT)
GPIO.setup(inr2,GPIO.OUT)
GPIO.setup(enr,GPIO.OUT)
GPIO.output(inr1,GPIO.LOW)
GPIO.output(inr2,GPIO.LOW)
pr=GPIO.PWM(enr,1000)

pl.start(100)
pr.start(100)

print("\n")
print("The default speed & direction of motor is LOW & Forward.....")
print("r-run s-stop tr-turnright tl-turnleft f-forward b-backward l-low m-medium h-high e-exit")
print("\n")    

while(1):

    x=raw_input()
    
    if x=='r':
        print("run")
        if(temp1==1):
         GPIO.output(inl1,GPIO.HIGH)
         GPIO.output(inl2,GPIO.LOW)
         
         GPIO.output(inr1,GPIO.HIGH)
         GPIO.output(inr2,GPIO.LOW)
         print("forward")
         x='z'
        else:
         GPIO.output(inl1,GPIO.LOW)
         GPIO.output(inl2,GPIO.HIGH)
         
         GPIO.output(inr1,GPIO.LOW)
         GPIO.output(inr2,GPIO.HIGH)
         print("backward")
         x='z'


    elif x=='s':
        print("stop")
        GPIO.output(inl1,GPIO.LOW)
        GPIO.output(inl2,GPIO.LOW)
        
        GPIO.output(inr1,GPIO.LOW)
        GPIO.output(inr2,GPIO.LOW)
        x='z'

    elif x=='f':
        print("forward")
        GPIO.output(inl1,GPIO.HIGH)
        GPIO.output(inl2,GPIO.LOW)
        
        GPIO.output(inr1,GPIO.HIGH)
        GPIO.output(inr2,GPIO.LOW)
        temp1=1
        x='z'

    elif x=='b':
        print("backward")
        GPIO.output(inl1,GPIO.LOW)
        GPIO.output(inl2,GPIO.HIGH)
        
        GPIO.output(inr1,GPIO.LOW)
        GPIO.output(inr2,GPIO.HIGH)
        temp1=0
        x='z'
#    elif x=='tr':
#        print("turn right")
#        GPIO.output(inr1,GPIO.LOW)
#        GPIO.output(inr2,GPIO.HIGH)
#        
#        GPIO.output(inl1,GPIO.LOW)
#        GPIO.output(inl2,GPIO.LOW)
#        temp1=0
#        x='z'
#     elif x=='tl':
#        print("turn left")
#        GPIO.output(inl1,GPIO.LOW)
#        GPIO.output(inl2,GPIO.HIGH)
#        
#        GPIO.output(inr1,GPIO.LOW)
#        GPIO.output(inr2,GPIO.LOW)
#        temp1=0
#        x='z'
    elif x=='l':
        print("low")
        pl.ChangeDutyCycle(25)
        pr.ChangeDutyCycle(25)
        x='z'

    elif x=='m':
        print("medium")
        pl.ChangeDutyCycle(50)
        pr.ChangeDutyCycle(50)
        x='z'

    elif x=='h':
        print("high")
        pl.ChangeDutyCycle(100)
        pr.ChangeDutyCycle(100)
        x='z'
     
    
    elif x=='e':
        GPIO.cleanup()
        print("GPIO Clean up")
        break
    
    else:
        print("<<<  wrong data  >>>")
        print("please enter the defined data to continue.....")